"""对话管理模块"""

import uuid
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict

from app.core.config import settings
from app.core.logger import logger
from app.models.schemas import ChatMessage, MessageRole, ConversationInfo


@dataclass
class Conversation:
    """对话数据类"""
    id: str
    title: str
    messages: List[ChatMessage]
    created_at: datetime
    updated_at: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "title": self.title,
            "messages": [
                {
                    "role": msg.role.value,
                    "content": msg.content,
                    "timestamp": msg.timestamp.isoformat(),
                    "sources": [
                        {
                            "content": s.content,
                            "source": s.source,
                            "score": s.score,
                            "metadata": s.metadata
                        } for s in (msg.sources or [])
                    ] if msg.sources else None
                }
                for msg in self.messages
            ],
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Conversation":
        """从字典创建"""
        from app.models.schemas import DocumentSource
        
        messages = []
        for msg_data in data.get("messages", []):
            sources = None
            if msg_data.get("sources"):
                sources = [
                    DocumentSource(
                        content=s["content"],
                        source=s["source"],
                        score=s["score"],
                        metadata=s.get("metadata", {})
                    )
                    for s in msg_data["sources"]
                ]
            
            messages.append(ChatMessage(
                role=MessageRole(msg_data["role"]),
                content=msg_data["content"],
                timestamp=datetime.fromisoformat(msg_data["timestamp"]),
                sources=sources
            ))
        
        return cls(
            id=data["id"],
            title=data.get("title", "新对话"),
            messages=messages,
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )


class ConversationManager:
    """对话管理器"""
    
    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(storage_path or "./data/conversations")
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.conversations: Dict[str, Conversation] = {}
        self._load_all_conversations()
    
    def _get_conversation_file(self, conversation_id: str) -> Path:
        """获取对话文件路径"""
        return self.storage_path / f"{conversation_id}.json"
    
    def _load_all_conversations(self):
        """加载所有对话"""
        try:
            for file_path in self.storage_path.glob("*.json"):
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        conversation = Conversation.from_dict(data)
                        self.conversations[conversation.id] = conversation
                except Exception as e:
                    logger.error(f"加载对话文件失败 {file_path}: {e}")
            
            logger.info(f"已加载 {len(self.conversations)} 个对话")
        except Exception as e:
            logger.error(f"加载对话失败: {e}")
    
    def _save_conversation(self, conversation: Conversation):
        """保存对话到文件"""
        try:
            file_path = self._get_conversation_file(conversation.id)
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(conversation.to_dict(), f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存对话失败 {conversation.id}: {e}")
    
    def create_conversation(self, title: Optional[str] = None) -> Conversation:
        """创建新对话
        
        Args:
            title: 对话标题
            
        Returns:
            新创建的对话
        """
        conversation_id = str(uuid.uuid4())
        now = datetime.now()
        
        conversation = Conversation(
            id=conversation_id,
            title=title or "新对话",
            messages=[],
            created_at=now,
            updated_at=now
        )
        
        self.conversations[conversation_id] = conversation
        self._save_conversation(conversation)
        
        logger.info(f"创建新对话: {conversation_id}")
        return conversation
    
    def get_conversation(self, conversation_id: str) -> Optional[Conversation]:
        """获取对话
        
        Args:
            conversation_id: 对话ID
            
        Returns:
            对话对象或None
        """
        return self.conversations.get(conversation_id)
    
    def add_message(
        self,
        conversation_id: str,
        role: MessageRole,
        content: str,
        sources: Optional[List[Any]] = None
    ) -> Optional[ChatMessage]:
        """添加消息到对话
        
        Args:
            conversation_id: 对话ID
            role: 消息角色
            content: 消息内容
            sources: 引用来源
            
        Returns:
            添加的消息或None
        """
        conversation = self.conversations.get(conversation_id)
        if not conversation:
            logger.warning(f"对话不存在: {conversation_id}")
            return None
        
        message = ChatMessage(
            role=role,
            content=content,
            timestamp=datetime.now(),
            sources=sources
        )
        
        conversation.messages.append(message)
        conversation.updated_at = datetime.now()
        
        # 如果是第一条用户消息，自动生成标题
        if role == MessageRole.USER and len(conversation.messages) == 1:
            conversation.title = self._generate_title(content)
        
        # 限制历史记录长度
        if len(conversation.messages) > settings.max_history_length * 2:
            conversation.messages = conversation.messages[-settings.max_history_length * 2:]
        
        self._save_conversation(conversation)
        return message
    
    def _generate_title(self, first_message: str, max_length: int = 20) -> str:
        """根据第一条消息生成标题
        
        Args:
            first_message: 第一条消息
            max_length: 最大长度
            
        Returns:
            生成的标题
        """
        # 去除多余空白
        title = first_message.strip()
        
        # 截取前max_length个字符
        if len(title) > max_length:
            title = title[:max_length] + "..."
        
        return title if title else "新对话"
    
    def get_conversation_history(
        self,
        conversation_id: str,
        limit: Optional[int] = None
    ) -> List[Dict[str, str]]:
        """获取对话历史（用于LLM上下文）
        
        Args:
            conversation_id: 对话ID
            limit: 限制返回的消息数量
            
        Returns:
            消息列表，格式 [{"role": "user", "content": "..."}, ...]
        """
        conversation = self.conversations.get(conversation_id)
        if not conversation:
            return []
        
        messages = conversation.messages
        if limit:
            messages = messages[-limit:]
        
        return [
            {"role": msg.role.value, "content": msg.content}
            for msg in messages
        ]
    
    def list_conversations(
        self,
        limit: int = 20,
        offset: int = 0
    ) -> List[ConversationInfo]:
        """列出对话
        
        Args:
            limit: 返回数量限制
            offset: 偏移量
            
        Returns:
            对话信息列表
        """
        sorted_conversations = sorted(
            self.conversations.values(),
            key=lambda c: c.updated_at,
            reverse=True
        )
        
        paginated = sorted_conversations[offset:offset + limit]
        
        return [
            ConversationInfo(
                id=c.id,
                title=c.title,
                created_at=c.created_at,
                updated_at=c.updated_at,
                message_count=len(c.messages)
            )
            for c in paginated
        ]
    
    def delete_conversation(self, conversation_id: str) -> bool:
        """删除对话
        
        Args:
            conversation_id: 对话ID
            
        Returns:
            是否成功
        """
        if conversation_id not in self.conversations:
            return False
        
        try:
            # 删除内存中的对话
            del self.conversations[conversation_id]
            
            # 删除文件
            file_path = self._get_conversation_file(conversation_id)
            if file_path.exists():
                file_path.unlink()
            
            logger.info(f"删除对话: {conversation_id}")
            return True
        except Exception as e:
            logger.error(f"删除对话失败 {conversation_id}: {e}")
            return False
    
    def update_conversation_title(
        self,
        conversation_id: str,
        new_title: str
    ) -> bool:
        """更新对话标题
        
        Args:
            conversation_id: 对话ID
            new_title: 新标题
            
        Returns:
            是否成功
        """
        conversation = self.conversations.get(conversation_id)
        if not conversation:
            return False
        
        conversation.title = new_title
        conversation.updated_at = datetime.now()
        self._save_conversation(conversation)
        
        return True
    
    def clear_all_conversations(self) -> bool:
        """清空所有对话
        
        Returns:
            是否成功
        """
        try:
            self.conversations.clear()
            
            # 删除所有对话文件
            for file_path in self.storage_path.glob("*.json"):
                file_path.unlink()
            
            logger.info("已清空所有对话")
            return True
        except Exception as e:
            logger.error(f"清空对话失败: {e}")
            return False


# 全局对话管理器实例
_conversation_manager: Optional[ConversationManager] = None


def get_conversation_manager() -> ConversationManager:
    """获取对话管理器单例"""
    global _conversation_manager
    if _conversation_manager is None:
        _conversation_manager = ConversationManager()
    return _conversation_manager
