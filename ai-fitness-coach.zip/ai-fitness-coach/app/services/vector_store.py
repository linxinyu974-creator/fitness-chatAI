"""向量数据库服务 - 基于 ChromaDB"""

import uuid
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import chromadb
from chromadb.config import Settings as ChromaSettings

from app.core.config import settings
from app.core.logger import logger
from app.services.ollama_client import get_ollama_client


class VectorStore:
    """向量数据库服务类"""
    
    def __init__(self, collection_name: Optional[str] = None):
        self.collection_name = collection_name or settings.collection_name
        self.persist_directory = settings.vector_db_path
        self.chunk_size = settings.chunk_size
        self.chunk_overlap = settings.chunk_overlap
        self.top_k = settings.top_k_retrieval
        
        # 确保目录存在
        Path(self.persist_directory).mkdir(parents=True, exist_ok=True)
        
        # 初始化 ChromaDB 客户端 (新版API)
        self.client = chromadb.PersistentClient(
            path=self.persist_directory
        )
        
        # 获取或创建集合
        self.collection = self._get_or_create_collection()
        
    def _get_or_create_collection(self):
        """获取或创建集合"""
        try:
            collection = self.client.get_collection(name=self.collection_name)
            logger.info(f"已加载现有集合: {self.collection_name}")
        except Exception:
            collection = self.client.create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            logger.info(f"创建新集合: {self.collection_name}")
        return collection
    
    def _chunk_text(self, text: str, chunk_size: Optional[int] = None) -> List[str]:
        """将文本切分成块
        
        Args:
            text: 原始文本
            chunk_size: 块大小
            
        Returns:
            文本块列表
        """
        chunk_size = chunk_size or self.chunk_size
        overlap = self.chunk_overlap
        
        chunks = []
        start = 0
        text_len = len(text)
        
        while start < text_len:
            end = min(start + chunk_size, text_len)
            
            # 尝试在句子边界处切分
            if end < text_len:
                # 寻找最近的句号、问号或感叹号
                for i in range(end - 1, start, -1):
                    if text[i] in '。！？.!?':
                        end = i + 1
                        break
            
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            # 移动窗口，考虑重叠
            start = end - overlap if end < text_len else text_len
            
        return chunks
    
    async def add_document(
        self,
        content: str,
        source: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, int]:
        """添加文档到向量数据库
        
        Args:
            content: 文档内容
            source: 文档来源
            metadata: 元数据
            
        Returns:
            (是否成功, 切分块数)
        """
        try:
            # 切分文档
            chunks = self._chunk_text(content)
            
            if not chunks:
                logger.warning(f"文档 {source} 切分后为空")
                return False, 0
            
            # 生成嵌入向量
            ollama_client = get_ollama_client()
            embeddings = await ollama_client.generate_embeddings_batch(chunks)
            
            # 准备数据
            ids = [str(uuid.uuid4()) for _ in chunks]
            metadatas = []
            for i, chunk in enumerate(chunks):
                meta = {
                    "source": source,
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    **(metadata or {})
                }
                metadatas.append(meta)
            
            # 添加到集合
            self.collection.add(
                ids=ids,
                embeddings=embeddings,
                documents=chunks,
                metadatas=metadatas
            )
            
            logger.info(f"成功添加文档 {source}，共 {len(chunks)} 个块")
            return True, len(chunks)
            
        except Exception as e:
            logger.error(f"添加文档失败 {source}: {e}")
            return False, 0
    
    async def add_documents_batch(
        self,
        documents: List[Tuple[str, str, Optional[Dict[str, Any]]]]
    ) -> List[Tuple[bool, int]]:
        """批量添加文档
        
        Args:
            documents: 文档列表，每项为 (content, source, metadata)
            
        Returns:
            结果列表，每项为 (是否成功, 切分块数)
        """
        results = []
        for content, source, metadata in documents:
            result = await self.add_document(content, source, metadata)
            results.append(result)
        return results
    
    async def search(
        self,
        query: str,
        top_k: Optional[int] = None,
        filter_dict: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """语义检索
        
        Args:
            query: 查询文本
            top_k: 返回结果数量
            filter_dict: 过滤条件
            
        Returns:
            检索结果列表
        """
        try:
            top_k = top_k or self.top_k
            
            # 生成查询向量
            ollama_client = get_ollama_client()
            query_embedding = await ollama_client.generate_embedding(query)
            
            # 执行检索
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                where=filter_dict,
                include=["documents", "metadatas", "distances"]
            )
            
            # 格式化结果
            formatted_results = []
            if results["ids"] and results["ids"][0]:
                for i, doc_id in enumerate(results["ids"][0]):
                    distance = results["distances"][0][i] if results["distances"] else 1.0
                    # 将距离转换为相似度分数 (cosine distance -> similarity)
                    similarity = 1 - distance
                    
                    formatted_results.append({
                        "id": doc_id,
                        "content": results["documents"][0][i] if results["documents"] else "",
                        "source": results["metadatas"][0][i].get("source", "unknown") if results["metadatas"] else "unknown",
                        "score": round(similarity, 4),
                        "metadata": results["metadatas"][0][i] if results["metadatas"] else {}
                    })
            
            return formatted_results
            
        except Exception as e:
            logger.error(f"检索失败: {e}")
            return []
    
    def delete_document(self, source: str) -> bool:
        """删除指定来源的所有文档块
        
        Args:
            source: 文档来源
            
        Returns:
            是否成功
        """
        try:
            self.collection.delete(where={"source": source})
            logger.info(f"已删除文档: {source}")
            return True
        except Exception as e:
            logger.error(f"删除文档失败 {source}: {e}")
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息
        
        Returns:
            统计信息字典
        """
        try:
            count = self.collection.count()
            
            # 获取所有唯一的 source
            all_data = self.collection.get(include=["metadatas"])
            sources = set()
            if all_data["metadatas"]:
                for meta in all_data["metadatas"]:
                    sources.add(meta.get("source", "unknown"))
            
            return {
                "total_documents": len(sources),
                "total_chunks": count,
                "collection_name": self.collection_name,
                "embedding_model": settings.ollama_embedding_model
            }
        except Exception as e:
            logger.error(f"获取统计信息失败: {e}")
            return {
                "total_documents": 0,
                "total_chunks": 0,
                "collection_name": self.collection_name,
                "embedding_model": settings.ollama_embedding_model
            }
    
    def clear_collection(self) -> bool:
        """清空集合
        
        Returns:
            是否成功
        """
        try:
            self.client.delete_collection(name=self.collection_name)
            self.collection = self._get_or_create_collection()
            logger.info("已清空向量数据库")
            return True
        except Exception as e:
            logger.error(f"清空集合失败: {e}")
            return False
    
    def persist(self):
        """持久化数据"""
        try:
            self.client.persist()
            logger.info("向量数据库已持久化")
        except Exception as e:
            logger.error(f"持久化失败: {e}")


# 全局向量存储实例
_vector_store: Optional[VectorStore] = None


def get_vector_store() -> VectorStore:
    """获取向量存储单例"""
    global _vector_store
    if _vector_store is None:
        _vector_store = VectorStore()
    return _vector_store
