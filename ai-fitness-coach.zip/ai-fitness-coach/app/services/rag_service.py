"""RAG (检索增强生成) 服务"""

from pathlib import Path
from typing import List, Dict, Any, Optional, AsyncGenerator
import re

from app.core.config import settings
from app.core.logger import logger
from app.services.ollama_client import get_ollama_client
from app.services.vector_store import get_vector_store
from app.models.schemas import DocumentSource


class RAGService:
    """RAG 服务类"""
    
    # 健身教练系统提示词
    FITNESS_COACH_SYSTEM_PROMPT = """你是一位专业的AI健身教练，拥有丰富的运动科学、营养学和健康知识。

你的职责是：
1. 根据用户的健身目标、身体状况和训练经验，提供个性化的训练建议
2. 解答关于运动技巧、训练计划、营养补充、恢复休息等方面的问题
3. 提供科学、安全、可行的健身指导
4. 鼓励用户坚持锻炼，培养健康的生活方式

回答原则：
- 基于提供的参考资料进行回答，确保信息准确
- 如果参考资料不足以回答问题，可以基于你的专业知识补充
- 对于涉及医疗诊断或治疗的问题，建议用户咨询专业医生
- 回答要具体、实用，避免过于笼统的建议
- 语气要友好、专业、有鼓励性

请记住：安全第一，循序渐进，持之以恒是健身成功的关键。"""

    def __init__(self):
        self.ollama_client = get_ollama_client()
        self.vector_store = get_vector_store()
        self.similarity_threshold = settings.similarity_threshold
    
    def _build_prompt(
        self,
        query: str,
        retrieved_docs: List[DocumentSource],
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> str:
        """构建 RAG 提示词
        
        Args:
            query: 用户查询
            retrieved_docs: 检索到的文档
            conversation_history: 对话历史
            
        Returns:
            完整的提示词
        """
        # 构建上下文部分
        context_parts = []
        for i, doc in enumerate(retrieved_docs, 1):
            context_parts.append(f"[参考{i}] {doc.content}\n来源: {doc.source}")
        
        context = "\n\n".join(context_parts) if context_parts else "无相关参考资料"
        
        # 构建历史对话部分
        history_text = ""
        if conversation_history:
            history_parts = []
            for msg in conversation_history[-settings.max_history_length:]:
                role = "用户" if msg["role"] == "user" else "助手"
                history_parts.append(f"{role}: {msg['content']}")
            history_text = "\n".join(history_parts)
        
        # 构建完整提示词
        prompt = f"""以下是相关的参考资料：

{context}

{"---" if history_text else ""}
{history_text}
{"---" if history_text else ""}

用户问题：{query}

请基于参考资料和你的专业知识，以专业健身教练的身份回答用户的问题。如果参考资料中有相关信息，请优先使用。回答要具体、实用、有针对性。"""
        
        return prompt
    
    async def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None
    ) -> List[DocumentSource]:
        """检索相关文档
        
        Args:
            query: 查询文本
            top_k: 返回结果数量
            
        Returns:
            检索结果列表
        """
        results = await self.vector_store.search(query, top_k=top_k)
        
        # 过滤低相似度结果
        filtered_results = [
            r for r in results 
            if r["score"] >= self.similarity_threshold
        ]
        
        # 转换为 DocumentSource 对象
        sources = [
            DocumentSource(
                content=r["content"],
                source=r["source"],
                score=r["score"],
                metadata=r.get("metadata", {})
            )
            for r in filtered_results
        ]
        
        logger.info(f"检索到 {len(sources)} 条相关文档")
        return sources
    
    async def generate_answer(
        self,
        query: str,
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> tuple[str, List[DocumentSource]]:
        """生成回答（非流式）
        
        Args:
            query: 用户查询
            conversation_history: 对话历史
            
        Returns:
            (生成的回答, 引用的文档)
        """
        # 检索相关文档
        sources = await self.retrieve(query)
        
        # 构建提示词
        prompt = self._build_prompt(query, sources, conversation_history)
        
        # 生成回答
        answer = await self.ollama_client.generate(
            prompt=prompt,
            system_prompt=self.FITNESS_COACH_SYSTEM_PROMPT,
            temperature=0.7,
            max_tokens=settings.max_tokens_per_message
        )
        
        return answer, sources
    
    async def generate_answer_stream(
        self,
        query: str,
        conversation_history: Optional[List[Dict[str, str]]] = None
    ) -> AsyncGenerator[tuple[str, List[DocumentSource]], None]:
        """流式生成回答
        
        Args:
            query: 用户查询
            conversation_history: 对话历史
            
        Yields:
            (生成的文本片段, 引用的文档列表)
        """
        # 检索相关文档
        sources = await self.retrieve(query)
        
        # 构建提示词
        prompt = self._build_prompt(query, sources, conversation_history)
        
        # 流式生成
        async for chunk in self.ollama_client.generate_stream(
            prompt=prompt,
            system_prompt=self.FITNESS_COACH_SYSTEM_PROMPT,
            temperature=0.7,
            max_tokens=settings.max_tokens_per_message
        ):
            yield chunk, sources
    
    async def add_knowledge_document(
        self,
        content: str,
        source: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> tuple[bool, int]:
        """添加知识文档
        
        Args:
            content: 文档内容
            source: 文档来源标识
            metadata: 元数据
            
        Returns:
            (是否成功, 切分块数)
        """
        return await self.vector_store.add_document(content, source, metadata)
    
    async def add_knowledge_from_file(
        self,
        file_path: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> tuple[bool, int]:
        """从文件添加知识
        
        Args:
            file_path: 文件路径
            metadata: 元数据
            
        Returns:
            (是否成功, 切分块数)
        """
        path = Path(file_path)
        
        if not path.exists():
            logger.error(f"文件不存在: {file_path}")
            return False, 0
        
        try:
            content = self._read_file(file_path)
            if not content:
                return False, 0
            
            meta = {
                "filename": path.name,
                "file_type": path.suffix,
                **(metadata or {})
            }
            
            return await self.add_knowledge_document(content, str(path), meta)
            
        except Exception as e:
            logger.error(f"读取文件失败 {file_path}: {e}")
            return False, 0
    
    def _read_file(self, file_path: str) -> str:
        """读取文件内容
        
        Args:
            file_path: 文件路径
            
        Returns:
            文件内容
        """
        path = Path(file_path)
        suffix = path.suffix.lower()
        
        try:
            if suffix == ".txt" or suffix == ".md":
                with open(path, "r", encoding="utf-8") as f:
                    return f.read()
            
            elif suffix == ".pdf":
                try:
                    from pypdf import PdfReader
                    reader = PdfReader(path)
                    text = ""
                    for page in reader.pages:
                        text += page.extract_text() + "\n"
                    return text
                except ImportError:
                    logger.error("pypdf 未安装，无法读取PDF文件")
                    return ""
            
            elif suffix == ".docx":
                try:
                    from docx import Document
                    doc = Document(path)
                    text = "\n".join([para.text for para in doc.paragraphs])
                    return text
                except ImportError:
                    logger.error("python-docx 未安装，无法读取DOCX文件")
                    return ""
            
            else:
                logger.warning(f"不支持的文件类型: {suffix}")
                return ""
                
        except Exception as e:
            logger.error(f"读取文件失败: {e}")
            return ""
    
    def get_knowledge_stats(self) -> Dict[str, Any]:
        """获取知识库统计信息"""
        return self.vector_store.get_stats()
    
    def delete_knowledge_document(self, source: str) -> bool:
        """删除知识文档
        
        Args:
            source: 文档来源
            
        Returns:
            是否成功
        """
        return self.vector_store.delete_document(source)
    
    def clear_knowledge_base(self) -> bool:
        """清空知识库
        
        Returns:
            是否成功
        """
        return self.vector_store.clear_collection()


# 全局 RAG 服务实例
_rag_service: Optional[RAGService] = None


def get_rag_service() -> RAGService:
    """获取 RAG 服务单例"""
    global _rag_service
    if _rag_service is None:
        _rag_service = RAGService()
    return _rag_service
