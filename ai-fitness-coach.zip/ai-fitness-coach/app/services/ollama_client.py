"""Ollama API 客户端封装"""

import asyncio
import httpx
from typing import AsyncGenerator, List, Dict, Any, Optional
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import settings
from app.core.logger import logger


class OllamaClient:
    """Ollama API 客户端"""
    
    def __init__(self, host: Optional[str] = None):
        self.host = host or settings.ollama_host
        self.embedding_model = settings.ollama_embedding_model
        self.llm_model = settings.ollama_llm_model
        self.timeout = settings.ollama_timeout
        
    def _get_client(self) -> httpx.AsyncClient:
        """获取 HTTP 客户端"""
        return httpx.AsyncClient(
            base_url=self.host,
            timeout=self.timeout,
            headers={"Content-Type": "application/json"}
        )
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10)
    )
    async def generate_embedding(self, text: str) -> List[float]:
        """生成文本嵌入向量
        
        Args:
            text: 输入文本
            
        Returns:
            嵌入向量
        """
        async with self._get_client() as client:
            try:
                response = await client.post(
                    "/api/embeddings",
                    json={
                        "model": self.embedding_model,
                        "prompt": text
                    }
                )
                response.raise_for_status()
                data = response.json()
                return data.get("embedding", [])
            except Exception as e:
                logger.error(f"生成嵌入向量失败: {e}")
                raise
    
    async def generate_embeddings_batch(
        self, 
        texts: List[str],
        batch_size: int = 8
    ) -> List[List[float]]:
        """批量生成嵌入向量
        
        Args:
            texts: 文本列表
            batch_size: 批次大小
            
        Returns:
            嵌入向量列表
        """
        embeddings = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            tasks = [self.generate_embedding(text) for text in batch]
            batch_embeddings = await asyncio.gather(*tasks, return_exceptions=True)
            
            for emb in batch_embeddings:
                if isinstance(emb, Exception):
                    logger.error(f"批量嵌入生成失败: {emb}")
                    embeddings.append([])
                else:
                    embeddings.append(emb)
                    
        return embeddings
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10)
    )
    async def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False
    ) -> str:
        """生成文本回复
        
        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_tokens: 最大token数
            stream: 是否流式返回
            
        Returns:
            生成的文本
        """
        async with self._get_client() as client:
            try:
                payload = {
                    "model": self.llm_model,
                    "prompt": prompt,
                    "stream": stream,
                    "options": {
                        "temperature": temperature
                    }
                }
                
                if system_prompt:
                    payload["system"] = system_prompt
                    
                if max_tokens:
                    payload["options"]["num_predict"] = max_tokens
                
                response = await client.post("/api/generate", json=payload)
                response.raise_for_status()
                
                if stream:
                    # 流式处理在 generate_stream 方法中
                    return ""
                
                data = response.json()
                return data.get("response", "")
                
            except Exception as e:
                logger.error(f"生成文本失败: {e}")
                raise
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None
    ) -> AsyncGenerator[str, None]:
        """流式生成文本回复
        
        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_tokens: 最大token数
            
        Yields:
            生成的文本片段
        """
        async with self._get_client() as client:
            try:
                payload = {
                    "model": self.llm_model,
                    "prompt": prompt,
                    "stream": True,
                    "options": {
                        "temperature": temperature
                    }
                }
                
                if system_prompt:
                    payload["system"] = system_prompt
                    
                if max_tokens:
                    payload["options"]["num_predict"] = max_tokens
                
                async with client.stream(
                    "POST", 
                    "/api/generate", 
                    json=payload
                ) as response:
                    response.raise_for_status()
                    
                    async for line in response.aiter_lines():
                        if line.strip():
                            try:
                                import json
                                data = json.loads(line)
                                if "response" in data:
                                    yield data["response"]
                                if data.get("done", False):
                                    break
                            except json.JSONDecodeError:
                                continue
                                
            except Exception as e:
                logger.error(f"流式生成失败: {e}")
                raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10)
    )
    async def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False
    ) -> str:
        """对话生成
        
        Args:
            messages: 消息列表，格式 [{"role": "user", "content": "..."}, ...]
            temperature: 温度参数
            max_tokens: 最大token数
            stream: 是否流式返回
            
        Returns:
            生成的回复
        """
        async with self._get_client() as client:
            try:
                payload = {
                    "model": self.llm_model,
                    "messages": messages,
                    "stream": stream,
                    "options": {
                        "temperature": temperature
                    }
                }
                
                if max_tokens:
                    payload["options"]["num_predict"] = max_tokens
                
                response = await client.post("/api/chat", json=payload)
                response.raise_for_status()
                
                if stream:
                    return ""
                
                data = response.json()
                return data.get("message", {}).get("content", "")
                
            except Exception as e:
                logger.error(f"对话生成失败: {e}")
                raise
    
    async def chat_stream(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None
    ) -> AsyncGenerator[str, None]:
        """流式对话生成
        
        Args:
            messages: 消息列表
            temperature: 温度参数
            max_tokens: 最大token数
            
        Yields:
            生成的文本片段
        """
        async with self._get_client() as client:
            try:
                payload = {
                    "model": self.llm_model,
                    "messages": messages,
                    "stream": True,
                    "options": {
                        "temperature": temperature
                    }
                }
                
                if max_tokens:
                    payload["options"]["num_predict"] = max_tokens
                
                async with client.stream(
                    "POST", 
                    "/api/chat", 
                    json=payload
                ) as response:
                    response.raise_for_status()
                    
                    async for line in response.aiter_lines():
                        if line.strip():
                            try:
                                import json
                                data = json.loads(line)
                                if "message" in data and "content" in data["message"]:
                                    yield data["message"]["content"]
                                if data.get("done", False):
                                    break
                            except json.JSONDecodeError:
                                continue
                                
            except Exception as e:
                logger.error(f"流式对话生成失败: {e}")
                raise
    
    async def health_check(self) -> Dict[str, Any]:
        """检查 Ollama 服务状态
        
        Returns:
            服务状态信息
        """
        try:
            async with self._get_client() as client:
                response = await client.get("/api/tags")
                response.raise_for_status()
                data = response.json()
                
                models = [m.get("name") for m in data.get("models", [])]
                
                return {
                    "connected": True,
                    "available_models": models,
                    "embedding_model_ready": self.embedding_model in models,
                    "llm_model_ready": self.llm_model in models
                }
        except Exception as e:
            logger.error(f"Ollama 健康检查失败: {e}")
            return {
                "connected": False,
                "error": str(e),
                "available_models": [],
                "embedding_model_ready": False,
                "llm_model_ready": False
            }


# 全局客户端实例
_ollama_client: Optional[OllamaClient] = None


def get_ollama_client() -> OllamaClient:
    """获取 Ollama 客户端单例"""
    global _ollama_client
    if _ollama_client is None:
        _ollama_client = OllamaClient()
    return _ollama_client
