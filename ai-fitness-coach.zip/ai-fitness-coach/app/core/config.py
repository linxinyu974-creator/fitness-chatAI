"""应用配置管理模块"""

from functools import lru_cache
from typing import List, Optional
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """应用配置类"""
    
    # 应用信息
    app_name: str = Field(default="AI Fitness Coach", description="应用名称")
    app_version: str = Field(default="1.0.0", description="应用版本")
    debug: bool = Field(default=False, description="调试模式")
    
    # Ollama 配置
    ollama_host: str = Field(default="http://localhost:11434", description="Ollama服务地址")
    ollama_embedding_model: str = Field(default="bge-m3:latest", description="嵌入模型名称")
    ollama_llm_model: str = Field(default="deepseek-r1:7b", description="大语言模型名称")
    ollama_timeout: int = Field(default=120, description="Ollama请求超时时间(秒)")
    
    # 向量数据库配置
    vector_db_path: str = Field(default="./data/vector_db", description="向量数据库路径")
    collection_name: str = Field(default="fitness_knowledge", description="集合名称")
    
    # 文档切分配置
    chunk_size: int = Field(default=512, description="文档切分大小")
    chunk_overlap: int = Field(default=50, description="文档切分重叠大小")
    
    # 检索配置
    top_k_retrieval: int = Field(default=5, description="检索返回的最相关文档数量")
    similarity_threshold: float = Field(default=0.5, description="相似度阈值")
    
    # API 配置
    api_host: str = Field(default="0.0.0.0", description="API服务地址")
    api_port: int = Field(default=8003, description="API服务端口")
    
    # 对话配置
    max_history_length: int = Field(default=10, description="最大历史对话轮数")
    max_tokens_per_message: int = Field(default=2048, description="每条消息最大token数")
    
    # CORS 配置
    cors_origins: List[str] = Field(default=["*"], description="允许的跨域来源")
    
    # 知识库配置
    knowledge_base_path: str = Field(default="./data/knowledge_base", description="知识库文件路径")
    supported_extensions: List[str] = Field(
        default=[".txt", ".md", ".pdf", ".docx"],
        description="支持的知识库文件扩展名"
    )
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()


# 导出配置实例
settings = get_settings()
