"""FastAPI 路由定义"""

import json
from typing import List, Optional
from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Depends
from fastapi.responses import StreamingResponse

from app.core.config import settings
from app.core.logger import logger
from app.models.schemas import (
    ChatRequest, ChatResponse, ConversationInfo,
    DocumentUploadResponse, KnowledgeBaseStats, HealthCheckResponse,
    ModelInfo, MessageRole
)
from app.services.rag_service import get_rag_service
from app.services.conversation_manager import get_conversation_manager
from app.services.ollama_client import get_ollama_client


router = APIRouter()


# ============ 健康检查 ============

@router.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """健康检查接口"""
    ollama_client = get_ollama_client()
    ollama_status = await ollama_client.health_check()
    
    # 检查向量数据库
    try:
        rag_service = get_rag_service()
        vector_db_stats = rag_service.get_knowledge_stats()
        vector_db_ready = True
    except Exception:
        vector_db_ready = False
    
    return HealthCheckResponse(
        status="healthy",
        version=settings.app_version,
        ollama_connected=ollama_status["connected"],
        vector_db_ready=vector_db_ready
    )


@router.get("/models", response_model=List[ModelInfo])
async def list_models():
    """获取可用模型列表"""
    ollama_client = get_ollama_client()
    status = await ollama_client.health_check()
    
    if not status["connected"]:
        raise HTTPException(status_code=503, detail="Ollama 服务未连接")
    
    models = []
    for model_name in status.get("available_models", []):
        model_type = "embedding" if model_name == settings.ollama_embedding_model else "llm"
        if model_name == settings.ollama_llm_model:
            model_type = "llm"
        
        models.append(ModelInfo(
            name=model_name,
            type=model_type,
            status="ready"
        ))
    
    return models


# ============ 对话接口 ============

@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """非流式对话接口"""
    try:
        rag_service = get_rag_service()
        conversation_manager = get_conversation_manager()
        
        # 获取或创建对话
        if request.conversation_id:
            conversation = conversation_manager.get_conversation(request.conversation_id)
            if not conversation:
                raise HTTPException(status_code=404, detail="对话不存在")
            conversation_id = request.conversation_id
        else:
            conversation = conversation_manager.create_conversation()
            conversation_id = conversation.id
        
        # 添加用户消息
        conversation_manager.add_message(
            conversation_id=conversation_id,
            role=MessageRole.USER,
            content=request.message
        )
        
        # 获取对话历史
        history = conversation_manager.get_conversation_history(conversation_id)
        
        # 生成回答
        answer, sources = await rag_service.generate_answer(
            query=request.message,
            conversation_history=history[:-1]  # 不包含刚添加的用户消息
        )
        
        # 添加助手消息
        conversation_manager.add_message(
            conversation_id=conversation_id,
            role=MessageRole.ASSISTANT,
            content=answer,
            sources=sources
        )
        
        return ChatResponse(
            message=answer,
            conversation_id=conversation_id,
            sources=sources
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"对话失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    """流式对话接口"""
    try:
        rag_service = get_rag_service()
        conversation_manager = get_conversation_manager()
        
        # 获取或创建对话
        if request.conversation_id:
            conversation = conversation_manager.get_conversation(request.conversation_id)
            if not conversation:
                raise HTTPException(status_code=404, detail="对话不存在")
            conversation_id = request.conversation_id
        else:
            conversation = conversation_manager.create_conversation()
            conversation_id = conversation.id
        
        # 添加用户消息
        conversation_manager.add_message(
            conversation_id=conversation_id,
            role=MessageRole.USER,
            content=request.message
        )
        
        # 获取对话历史
        history = conversation_manager.get_conversation_history(conversation_id)
        
        # 流式生成
        async def generate_stream():
            full_response = ""
            sources_list = []
            
            async for chunk, sources in rag_service.generate_answer_stream(
                query=request.message,
                conversation_history=history[:-1]
            ):
                full_response += chunk
                if sources and not sources_list:
                    sources_list = sources
                
                data = {
                    "chunk": chunk,
                    "conversation_id": conversation_id,
                    "finished": False
                }
                yield f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
            
            # 添加助手消息到历史
            conversation_manager.add_message(
                conversation_id=conversation_id,
                role=MessageRole.ASSISTANT,
                content=full_response,
                sources=sources_list
            )
            
            # 发送结束标记
            final_data = {
                "chunk": "",
                "conversation_id": conversation_id,
                "sources": [
                    {
                        "content": s.content,
                        "source": s.source,
                        "score": s.score
                    }
                    for s in sources_list
                ],
                "finished": True
            }
            yield f"data: {json.dumps(final_data, ensure_ascii=False)}\n\n"
        
        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Conversation-Id": conversation_id
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"流式对话失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============ 对话管理接口 ============

@router.get("/conversations", response_model=List[ConversationInfo])
async def list_conversations(limit: int = 20, offset: int = 0):
    """获取对话列表"""
    conversation_manager = get_conversation_manager()
    return conversation_manager.list_conversations(limit=limit, offset=offset)


@router.post("/conversations")
async def create_conversation(title: Optional[str] = None):
    """创建新对话"""
    conversation_manager = get_conversation_manager()
    conversation = conversation_manager.create_conversation(title=title)
    return {
        "id": conversation.id,
        "title": conversation.title,
        "created_at": conversation.created_at
    }


@router.get("/conversations/{conversation_id}")
async def get_conversation(conversation_id: str):
    """获取对话详情"""
    conversation_manager = get_conversation_manager()
    conversation = conversation_manager.get_conversation(conversation_id)
    
    if not conversation:
        raise HTTPException(status_code=404, detail="对话不存在")
    
    return conversation.to_dict()


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(conversation_id: str):
    """删除对话"""
    conversation_manager = get_conversation_manager()
    success = conversation_manager.delete_conversation(conversation_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="对话不存在")
    
    return {"success": True, "message": "对话已删除"}


@router.put("/conversations/{conversation_id}/title")
async def update_conversation_title(conversation_id: str, title: str = Form(...)):
    """更新对话标题"""
    conversation_manager = get_conversation_manager()
    success = conversation_manager.update_conversation_title(conversation_id, title)
    
    if not success:
        raise HTTPException(status_code=404, detail="对话不存在")
    
    return {"success": True, "message": "标题已更新"}


# ============ 知识库管理接口 ============

@router.get("/knowledge/stats", response_model=KnowledgeBaseStats)
async def get_knowledge_stats():
    """获取知识库统计信息"""
    rag_service = get_rag_service()
    stats = rag_service.get_knowledge_stats()
    return KnowledgeBaseStats(**stats)


@router.post("/knowledge/upload", response_model=DocumentUploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    metadata: Optional[str] = Form(default="{}")
):
    """上传文档到知识库"""
    try:
        meta = json.loads(metadata) if metadata else {}
        
        # 读取文件内容
        content = await file.read()
        text_content = content.decode("utf-8")
        
        rag_service = get_rag_service()
        success, chunks_count = await rag_service.add_knowledge_document(
            content=text_content,
            source=file.filename,
            metadata=meta
        )
        
        return DocumentUploadResponse(
            success=success,
            message="文档上传成功" if success else "文档上传失败",
            document_id=file.filename,
            chunks_count=chunks_count
        )
        
    except Exception as e:
        logger.error(f"上传文档失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/knowledge/text", response_model=DocumentUploadResponse)
async def add_text_document(
    content: str = Form(...),
    source: str = Form(...),
    metadata: Optional[str] = Form(default="{}")
):
    """添加文本到知识库"""
    try:
        meta = json.loads(metadata) if metadata else {}
        
        rag_service = get_rag_service()
        success, chunks_count = await rag_service.add_knowledge_document(
            content=content,
            source=source,
            metadata=meta
        )
        
        return DocumentUploadResponse(
            success=success,
            message="文档添加成功" if success else "文档添加失败",
            document_id=source,
            chunks_count=chunks_count
        )
        
    except Exception as e:
        logger.error(f"添加文档失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/knowledge/documents/{source:path}")
async def delete_document(source: str):
    """删除知识库文档"""
    rag_service = get_rag_service()
    success = rag_service.delete_knowledge_document(source)
    
    if not success:
        raise HTTPException(status_code=404, detail="文档不存在")
    
    return {"success": True, "message": "文档已删除"}


@router.delete("/knowledge/clear")
async def clear_knowledge_base():
    """清空知识库"""
    rag_service = get_rag_service()
    success = rag_service.clear_knowledge_base()
    
    if not success:
        raise HTTPException(status_code=500, detail="清空失败")
    
    return {"success": True, "message": "知识库已清空"}


@router.post("/knowledge/search")
async def search_knowledge(query: str = Form(...), top_k: int = 5):
    """搜索知识库"""
    rag_service = get_rag_service()
    results = await rag_service.retrieve(query, top_k=top_k)
    
    return {
        "query": query,
        "results": [
            {
                "content": r.content,
                "source": r.source,
                "score": r.score
            }
            for r in results
        ]
    }
