"""AI Fitness Coach - 基于Ollama的RAG智能健身教练"""

__version__ = "1.0.0"
__author__ = "AI Fitness Coach Team"
