// Global state
let currentConversationId = null;
let isStreaming = false;
let conversations = [];

// DOM Elements
const elements = {
    sidebar: document.getElementById('sidebar'),
    conversationsList: document.getElementById('conversationsList'),
    messagesContainer: document.getElementById('messagesContainer'),
    messageInput: document.getElementById('messageInput'),
    sendBtn: document.getElementById('sendBtn'),
    chatTitle: document.getElementById('chatTitle'),
    knowledgePanel: document.getElementById('knowledgePanel'),
    statusIndicator: document.getElementById('statusIndicator'),
    docCount: document.getElementById('docCount'),
    chunkCount: document.getElementById('chunkCount'),
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkHealth();
    loadConversations();
    loadKnowledgeStats();
    
    // Auto-check status every 30s
    setInterval(checkHealth, 30000);
});

// Health Check
async function checkHealth() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        
        const dot = elements.statusIndicator.querySelector('.status-dot');
        const text = elements.statusIndicator.querySelector('.status-text');
        
        if (data.ollama_connected && data.vector_db_ready) {
            dot.className = 'status-dot connected';
            text.textContent = '服务正常';
        } else {
            dot.className = 'status-dot error';
            text.textContent = '服务异常';
        }
    } catch (error) {
        const dot = elements.statusIndicator.querySelector('.status-dot');
        const text = elements.statusIndicator.querySelector('.status-text');
        dot.className = 'status-dot error';
        text.textContent = '连接失败';
    }
}

// Load Conversations
async function loadConversations() {
    try {
        const response = await fetch('/api/conversations');
        conversations = await response.json();
        renderConversations();
    } catch (error) {
        console.error('Failed to load conversations:', error);
    }
}

// Render Conversations List
function renderConversations() {
    elements.conversationsList.innerHTML = conversations.map(conv => `
        <div class="conversation-item ${conv.id === currentConversationId ? 'active' : ''}" 
             onclick="switchConversation('${conv.id}')">
            <div class="conversation-icon">💬</div>
            <div class="conversation-info">
                <div class="conversation-title">${escapeHtml(conv.title)}</div>
                <div class="conversation-time">${formatTime(conv.updated_at)}</div>
            </div>
        </div>
    `).join('');
}

// Create New Chat
async function createNewChat() {
    try {
        const response = await fetch('/api/conversations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        const conversation = await response.json();
        
        currentConversationId = conversation.id;
        elements.chatTitle.textContent = conversation.title;
        
        // Clear messages and show welcome
        elements.messagesContainer.innerHTML = `
            <div class="welcome-message">
                <div class="welcome-icon">💪</div>
                <h2>你好！我是你的 AI 健身教练</h2>
                <p>我可以帮你制定训练计划、解答健身问题、提供营养建议</p>
                <div class="quick-questions">
                    <button onclick="sendQuickQuestion('如何制定减脂训练计划？')">如何制定减脂训练计划？</button>
                    <button onclick="sendQuickQuestion('增肌期应该怎么吃？')">增肌期应该怎么吃？</button>
                    <button onclick="sendQuickQuestion('新手健身有什么建议？')">新手健身有什么建议？</button>
                    <button onclick="sendQuickQuestion('如何避免运动损伤？')">如何避免运动损伤？</button>
                </div>
            </div>
        `;
        
        await loadConversations();
        
        // Close sidebar on mobile
        if (window.innerWidth <= 768) {
            elements.sidebar.classList.remove('open');
        }
    } catch (error) {
        console.error('Failed to create conversation:', error);
        alert('创建对话失败');
    }
}

// Switch Conversation
async function switchConversation(conversationId) {
    currentConversationId = conversationId;
    
    try {
        const response = await fetch(`/api/conversations/${conversationId}`);
        const conversation = await response.json();
        
        elements.chatTitle.textContent = conversation.title;
        
        // Render messages
        if (conversation.messages && conversation.messages.length > 0) {
            elements.messagesContainer.innerHTML = conversation.messages.map(msg => {
                const isUser = msg.role === 'user';
                return `
                    <div class="message ${isUser ? 'user' : 'assistant'}">
                        <div class="message-avatar">${isUser ? '👤' : '💪'}</div>
                        <div class="message-content">
                            ${escapeHtml(msg.content)}
                            ${msg.sources && msg.sources.length > 0 ? `
                                <div class="message-sources">
                                    <div class="message-sources-title">参考来源：</div>
                                    ${msg.sources.map(s => `
                                        <div class="source-item">
                                            <span class="source-score">${(s.score * 100).toFixed(0)}%</span>
                                            <span>${escapeHtml(s.source)}</span>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `;
            }).join('');
            
            scrollToBottom();
        } else {
            elements.messagesContainer.innerHTML = `
                <div class="welcome-message">
                    <div class="welcome-icon">💪</div>
                    <h2>你好！我是你的 AI 健身教练</h2>
                    <p>我可以帮你制定训练计划、解答健身问题、提供营养建议</p>
                    <div class="quick-questions">
                        <button onclick="sendQuickQuestion('如何制定减脂训练计划？')">如何制定减脂训练计划？</button>
                        <button onclick="sendQuickQuestion('增肌期应该怎么吃？')">增肌期应该怎么吃？</button>
                        <button onclick="sendQuickQuestion('新手健身有什么建议？')">新手健身有什么建议？</button>
                        <button onclick="sendQuickQuestion('如何避免运动损伤？')">如何避免运动损伤？</button>
                    </div>
                </div>
            `;
        }
        
        renderConversations();
        
        // Close sidebar on mobile
        if (window.innerWidth <= 768) {
            elements.sidebar.classList.remove('open');
        }
    } catch (error) {
        console.error('Failed to load conversation:', error);
    }
}

// Send Message
async function sendMessage() {
    const message = elements.messageInput.value.trim();
    if (!message || isStreaming) return;
    
    // Create conversation if not exists
    if (!currentConversationId) {
        await createNewChat();
    }
    
    // Clear welcome message if exists
    const welcomeMessage = elements.messagesContainer.querySelector('.welcome-message');
    if (welcomeMessage) {
        welcomeMessage.remove();
    }
    
    // Add user message
    addMessageToUI('user', message);
    elements.messageInput.value = '';
    autoResize(elements.messageInput);
    
    // Show loading
    const loadingId = showLoading();
    isStreaming = true;
    elements.sendBtn.disabled = true;
    
    try {
        const response = await fetch('/api/chat/stream', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: message,
                conversation_id: currentConversationId,
                stream: true
            })
        });
        
        // Remove loading
        document.getElementById(loadingId).remove();
        
        // Create assistant message container
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message assistant';
        messageDiv.innerHTML = `
            <div class="message-avatar">💪</div>
            <div class="message-content"></div>
        `;
        elements.messagesContainer.appendChild(messageDiv);
        
        const contentDiv = messageDiv.querySelector('.message-content');
        let fullResponse = '';
        let sources = [];
        
        // Read stream
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const data = JSON.parse(line.slice(6));
                        
                        if (data.finished) {
                            sources = data.sources || [];
                            // Update conversation ID
                            if (data.conversation_id) {
                                currentConversationId = data.conversation_id;
                            }
                        } else {
                            fullResponse += data.chunk;
                            contentDiv.textContent = fullResponse;
                            scrollToBottom();
                        }
                    } catch (e) {
                        // Ignore parse errors
                    }
                }
            }
        }
        
        // Add sources if available
        if (sources.length > 0) {
            const sourcesDiv = document.createElement('div');
            sourcesDiv.className = 'message-sources';
            sourcesDiv.innerHTML = `
                <div class="message-sources-title">参考来源：</div>
                ${sources.map(s => `
                    <div class="source-item">
                        <span class="source-score">${(s.score * 100).toFixed(0)}%</span>
                        <span>${escapeHtml(s.source)}</span>
                    </div>
                `).join('')}
            `;
            contentDiv.appendChild(sourcesDiv);
        }
        
        scrollToBottom();
        await loadConversations();
        
    } catch (error) {
        console.error('Failed to send message:', error);
        document.getElementById(loadingId).remove();
        addMessageToUI('assistant', '抱歉，发生了错误，请稍后重试。');
    } finally {
        isStreaming = false;
        elements.sendBtn.disabled = false;
    }
}

// Send Quick Question
function sendQuickQuestion(question) {
    elements.messageInput.value = question;
    sendMessage();
}

// Add Message to UI
function addMessageToUI(role, content, sources = []) {
    const isUser = role === 'user';
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user' : 'assistant'}`;
    
    let sourcesHtml = '';
    if (sources && sources.length > 0) {
        sourcesHtml = `
            <div class="message-sources">
                <div class="message-sources-title">参考来源：</div>
                ${sources.map(s => `
                    <div class="source-item">
                        <span class="source-score">${(s.score * 100).toFixed(0)}%</span>
                        <span>${escapeHtml(s.source)}</span>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    messageDiv.innerHTML = `
        <div class="message-avatar">${isUser ? '👤' : '💪'}</div>
        <div class="message-content">
            ${escapeHtml(content)}
            ${sourcesHtml}
        </div>
    `;
    
    elements.messagesContainer.appendChild(messageDiv);
    scrollToBottom();
}

// Show Loading
function showLoading() {
    const id = 'loading-' + Date.now();
    const loadingDiv = document.createElement('div');
    loadingDiv.id = id;
    loadingDiv.className = 'message assistant';
    loadingDiv.innerHTML = `
        <div class="message-avatar">💪</div>
        <div class="message-content">
            <div class="loading-indicator">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;
    elements.messagesContainer.appendChild(loadingDiv);
    scrollToBottom();
    return id;
}

// Scroll to Bottom
function scrollToBottom() {
    elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight;
}

// Handle Key Down
function handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

// Auto Resize Textarea
function autoResize(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
}

// Toggle Sidebar
function toggleSidebar() {
    elements.sidebar.classList.toggle('open');
}

// Toggle Knowledge Panel
function toggleKnowledgePanel() {
    elements.knowledgePanel.classList.toggle('open');
    if (elements.knowledgePanel.classList.contains('open')) {
        loadKnowledgeStats();
    }
}

// Load Knowledge Stats
async function loadKnowledgeStats() {
    try {
        const response = await fetch('/api/knowledge/stats');
        const stats = await response.json();
        
        elements.docCount.textContent = stats.total_documents;
        elements.chunkCount.textContent = stats.total_chunks;
    } catch (error) {
        console.error('Failed to load knowledge stats:', error);
        elements.docCount.textContent = '-';
        elements.chunkCount.textContent = '-';
    }
}

// Switch Tab
function switchTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    document.getElementById('fileTab').classList.toggle('hidden', tab !== 'file');
    document.getElementById('textTab').classList.toggle('hidden', tab !== 'text');
}

// Handle File Select
async function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    await uploadFile(file);
}

// Handle Drop
function handleDrop(event) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    
    const files = event.dataTransfer.files;
    if (files.length > 0) {
        uploadFile(files[0]);
    }
}

function handleDragOver(event) {
    event.preventDefault();
    event.currentTarget.classList.add('dragover');
}

function handleDragLeave(event) {
    event.currentTarget.classList.remove('dragover');
}

// Upload File
async function uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    try {
        const response = await fetch('/api/knowledge/upload', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(`上传成功！文档被切分为 ${result.chunks_count} 个知识块`);
            loadKnowledgeStats();
        } else {
            alert('上传失败：' + result.message);
        }
    } catch (error) {
        console.error('Failed to upload file:', error);
        alert('上传失败');
    }
}

// Add Text Knowledge
async function addTextKnowledge() {
    const content = document.getElementById('knowledgeText').value.trim();
    const source = document.getElementById('knowledgeSource').value.trim() || '手动输入';
    
    if (!content) {
        alert('请输入知识内容');
        return;
    }
    
    const formData = new FormData();
    formData.append('content', content);
    formData.append('source', source);
    
    try {
        const response = await fetch('/api/knowledge/text', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(`添加成功！文档被切分为 ${result.chunks_count} 个知识块`);
            document.getElementById('knowledgeText').value = '';
            document.getElementById('knowledgeSource').value = '';
            loadKnowledgeStats();
        } else {
            alert('添加失败：' + result.message);
        }
    } catch (error) {
        console.error('Failed to add text knowledge:', error);
        alert('添加失败');
    }
}

// Clear Current Chat
async function clearCurrentChat() {
    if (!currentConversationId) return;
    
    if (!confirm('确定要清空当前对话吗？')) return;
    
    try {
        await fetch(`/api/conversations/${currentConversationId}`, {
            method: 'DELETE'
        });
        
        currentConversationId = null;
        elements.messagesContainer.innerHTML = `
            <div class="welcome-message">
                <div class="welcome-icon">💪</div>
                <h2>你好！我是你的 AI 健身教练</h2>
                <p>我可以帮你制定训练计划、解答健身问题、提供营养建议</p>
                <div class="quick-questions">
                    <button onclick="sendQuickQuestion('如何制定减脂训练计划？')">如何制定减脂训练计划？</button>
                    <button onclick="sendQuickQuestion('增肌期应该怎么吃？')">增肌期应该怎么吃？</button>
                    <button onclick="sendQuickQuestion('新手健身有什么建议？')">新手健身有什么建议？</button>
                    <button onclick="sendQuickQuestion('如何避免运动损伤？')">如何避免运动损伤？</button>
                </div>
            </div>
        `;
        elements.chatTitle.textContent = '新对话';
        
        await loadConversations();
    } catch (error) {
        console.error('Failed to clear chat:', error);
    }
}

// Utility Functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatTime(isoString) {
    const date = new Date(isoString);
    const now = new Date();
    const diff = now - date;
    
    // Less than 1 hour
    if (diff < 3600000) {
        const minutes = Math.floor(diff / 60000);
        return minutes < 1 ? '刚刚' : `${minutes}分钟前`;
    }
    
    // Less than 24 hours
    if (diff < 86400000) {
        const hours = Math.floor(diff / 3600000);
        return `${hours}小时前`;
    }
    
    // Format date
    return date.toLocaleDateString('zh-CN', {
        month: 'short',
        day: 'numeric'
    });
}
