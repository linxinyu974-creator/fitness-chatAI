"""Pydantic 数据模型定义"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field


class MessageRole(str, Enum):
    """消息角色枚举"""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class DocumentSource(BaseModel):
    """文档来源信息"""
    content: str = Field(..., description="文档内容")
    source: str = Field(..., description="文档来源")
    score: float = Field(..., description="相似度分数")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="元数据")


class ChatMessage(BaseModel):
    """聊天消息模型"""
    role: MessageRole = Field(..., description="消息角色")
    content: str = Field(..., description="消息内容")
    timestamp: datetime = Field(default_factory=datetime.now, description="时间戳")
    sources: Optional[List[DocumentSource]] = Field(default=None, description="引用来源")


class ChatRequest(BaseModel):
    """聊天请求模型"""
    message: str = Field(..., min_length=1, max_length=4000, description="用户消息")
    conversation_id: Optional[str] = Field(default=None, description="对话ID")
    stream: bool = Field(default=True, description="是否流式返回")


class ChatResponse(BaseModel):
    """聊天响应模型"""
    message: str = Field(..., description="AI回复内容")
    conversation_id: str = Field(..., description="对话ID")
    sources: List[DocumentSource] = Field(default_factory=list, description="引用来源")
    timestamp: datetime = Field(default_factory=datetime.now, description="时间戳")


class ConversationInfo(BaseModel):
    """对话信息模型"""
    id: str = Field(..., description="对话ID")
    title: str = Field(..., description="对话标题")
    created_at: datetime = Field(..., description="创建时间")
    updated_at: datetime = Field(..., description="更新时间")
    message_count: int = Field(default=0, description="消息数量")


class DocumentUploadRequest(BaseModel):
    """文档上传请求"""
    filename: str = Field(..., description="文件名")
    content: str = Field(..., description="文档内容")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="元数据")


class DocumentUploadResponse(BaseModel):
    """文档上传响应"""
    success: bool = Field(..., description="是否成功")
    message: str = Field(..., description="响应消息")
    document_id: Optional[str] = Field(default=None, description="文档ID")
    chunks_count: int = Field(default=0, description="切分块数")


class KnowledgeBaseStats(BaseModel):
    """知识库统计信息"""
    total_documents: int = Field(..., description="文档总数")
    total_chunks: int = Field(..., description="块总数")
    collection_name: str = Field(..., description="集合名称")
    embedding_model: str = Field(..., description="嵌入模型")


class HealthCheckResponse(BaseModel):
    """健康检查响应"""
    status: str = Field(..., description="服务状态")
    version: str = Field(..., description="版本号")
    ollama_connected: bool = Field(..., description="Ollama连接状态")
    vector_db_ready: bool = Field(..., description="向量数据库状态")
    timestamp: datetime = Field(default_factory=datetime.now, description="检查时间")


class ModelInfo(BaseModel):
    """模型信息"""
    name: str = Field(..., description="模型名称")
    type: str = Field(..., description="模型类型")
    status: str = Field(..., description="模型状态")
    details: Optional[Dict[str, Any]] = Field(default=None, description="详细信息")
